<?php

require "connect.php";

if($_SERVER['REQUEST_METHOD']=="POST"){
    #code...
    $response = array();
    $namaHerbal = $_POST['namaHerbal'];
    $deskripsi = $_POST['deskripsi'];
    $foto = $_POST['foto'];
    $createdBy = $_POST['createdBy'];
    
    $insert = "insert into herbal value(null,'$namaHerbal','$deskripsi','$foto','NOW()','$createdBy')";
    if (mysqli_query($con, $insert)){
        #code...
        $response['value']=1;
        $response['message']="Berhasil ditambahkan";
        echo json_encode($response);
    }else{
        $response['value']=0;
        $response['message']="Gagal ditambahkan";
        echo json_encode($response);
    }
}

?>