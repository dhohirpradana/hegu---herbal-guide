<?php

define('HOST','localhost');
define('USER','id12275919_hegu123');
define('PASS','hegu123');
define('DB','id12275919_hegu123');

$con = mysqli_connect(HOST,USER,PASS,DB) or die ('Tidak dapat koneksi');

?>