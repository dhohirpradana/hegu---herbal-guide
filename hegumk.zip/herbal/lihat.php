<?php
require"../connect.php";

$response = array();

$sql = mysqli_query($con, "SELECT a.*,b.nama FROM herbal a
LEFT JOIN user b ON a.createdBy = b.id");
while($a=mysqli_fetch_array($sql)){
    $b['id'] = $a['id'];
    $b['namaHerbal'] = $a['namaHerbal'];
    $b['deskripsi'] = $a['deskripsi'];
    $b['foto'] = $a['foto'];
    $b['createdDate'] = $a['createdDate'];
    $b['createdBy'] = $a['createdBy'];
    $b['nama'] = $a['nama'];
    
    array_push($response, $b);
    
}

echo json_encode($response);

?>