<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
require"../connect.php";

if($_SERVER['REQUEST_METHOD']=="POST"){
    #code...
    $response = array();
    $namaHerbal = $_POST['namaHerbal'];
    $deskripsi = $_POST['deskripsi'];
    $foto = $_FILES['foto']['name'];
    $createdBy = $_POST['createdBy'];
    
    $imagePath = "image/".$foto;
    
    move_uploaded_file($_FILES['foto']['tmp_name'],$imagePath);
    
        $insert = "INSERT INTO herbal VALUE(NULL,'$namaHerbal','$deskripsi','$foto',NOW(),'$createdBy')";
        if (mysqli_query($con, $insert)){
        $response['value']=1;
        $response['pesan']="done";
        echo json_encode($response);
        } else {
        $response['value']=0;
        $response['pesan']="undone";
        echo json_encode($response);
        }
    }
?>