<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
require"connect.php";

if($_SERVER['REQUEST_METHOD']=="POST"){
    #code...
    $response = array();
    $nik = $_POST['nik'];
    $telp = $_POST['telp'];
    $foto = $_FILES['foto']['name'];
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $nama = $_POST['nama'];
    
    $imagePath = "image/".$foto;
    
    move_uploaded_file($_FILES['foto']['tmp_name'],$imagePath);
    
    $cek = "SELECT * FROM user WHERE username='$username'";
    $result = mysqli_fetch_array(mysqli_query($con, $cek));
    
    if (isset($result)){
        $response['value']='2';
        $response['message']="Username sudah ada";
        echo json_encode($response);
    }else{
        $insert = "INSERT INTO user VALUE(NULL,'$username','$password','0','$nama','$nik','$telp','$foto')";
        if (mysqli_query($con, $insert)){
        $response['value']=1;
        $response['message']="Berhasil mendaftar";
        echo json_encode($response);
        
        $conf_subject = 'Hegu - Tunggu Konfirmasi';
        $conf_subjectForAdmin = 'Hegu - Konfirmasi Akun';
        // Who should the confirmation email be from?
        $conf_sender = 'Hegu - Herbal Guide <no-reply@hegumk.co.id>';
        $msg = $nama. ",\n\nTerimakasih telah melakukan pendaftaran kami akan mengonfirmasi akun anda sesegera mungkin.";
        $msgToAdmin = $username. "\nTelah melakukan pendaftaran, silahkan konfirmasi hir.";
        
        mail( $username, $conf_subject, $msg, 'From: ' . $conf_sender );
        mail( 'dhohirkudus@gmail.com', $conf_subjectForAdmin, $msgToAdmin, 'From: ' . $conf_sender );
        } else {
        $response['value']=0;
        $response['message']="Gagal mendaftar";
        echo json_encode($response);
        }
    }
    
    
    
}

?>